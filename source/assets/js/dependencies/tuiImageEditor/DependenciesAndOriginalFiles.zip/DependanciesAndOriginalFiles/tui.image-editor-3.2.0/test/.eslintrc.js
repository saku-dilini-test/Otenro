module.exports = {
    "rules": {
        "max-nested-callbacks": 0
    }
};
